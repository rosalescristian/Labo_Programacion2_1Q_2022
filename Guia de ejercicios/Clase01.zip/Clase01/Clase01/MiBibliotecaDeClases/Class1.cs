﻿using System;

namespace MiBibliotecaDeClases
{
    public class Class1
    {
    }
}
